#include <stdio.h>

int outsider_var;
char undefined_function();
